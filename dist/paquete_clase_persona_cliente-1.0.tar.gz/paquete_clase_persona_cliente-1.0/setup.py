from setuptools import setup

setup(
    name='paquete_clase_persona_cliente',
    version='1.0',
    description='un paquete con una clase cliente, que hereda de una clase persona',
    author='fracaro federico',
    packages=['paquete_clase_persona_cliente']
)